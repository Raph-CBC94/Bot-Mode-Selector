# Rage Bot

Bot Discord ultra-agressif qui répond à chaque message avec une insulte contextuelle et variée, propulsé par Groq (LLM) avec rotation de clés et file d'attente anti-crash.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — lancer le serveur + bot (port 5000)
- `pnpm run typecheck` — typecheck complet
- `pnpm run build` — typecheck + build tous les packages
- `pnpm --filter @workspace/api-server run build` — build seul l'api-server

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API : Express 5
- Bot Discord : discord.js v14
- LLM : Groq via API OpenAI-compat (`openai` SDK) — modèles llama-3.3-70b-versatile → llama-3.1-8b-instant → gemma2-9b-it
- Build : esbuild (ESM bundle)
- Déploiement : Docker + Render (render.yaml)

## Où les choses vivent

- `artifacts/api-server/src/bot/index.ts` — logique principale du bot (prompts, queue, rotation clés)
- `artifacts/api-server/src/bot/affinities.ts` — système d'affinités par utilisateur (persisté dans `data/`)
- `artifacts/api-server/src/index.ts` — point d'entrée serveur + démarrage bot
- `Dockerfile` — build multi-stage pour Render
- `render.yaml` — blueprint Render (toutes les env vars listées)

## Variables d'environnement requises

| Variable | Obligatoire | Description |
|---|---|---|
| `DISCORD_BOT_TOKEN` | ✅ | Token du bot Discord |
| `GROQ_API_KEY` | ✅ | Clé Groq principale |
| `GROQ_API_KEY_1` … `GROQ_API_KEY_5` | Optionnel | Clés supplémentaires (rotation anti-rate-limit) |
| `ALLOWED_CHANNEL_ID` | Optionnel | ID du salon Discord (si vide → répond partout) |

## Déploiement Render

1. Push le repo sur GitHub
2. Sur render.com → **New > Blueprint** → connecter le repo
3. Render lit `render.yaml` et crée le service automatiquement
4. Renseigner les variables d'environnement marquées `sync: false` dans le dashboard Render

## Architecture décisions

- **File d'attente par salon** : les messages d'un même salon sont traités en séquence pour éviter les appels API simultanés (cause du bug de crash multi-messages).
- **Rotation aléatoire des clés Groq** : les clés sont sélectionnées aléatoirement parmi celles non rate-limitées. Chaque clé en 429 est mise en cooldown avec le `retry-after` parsé.
- **3 modèles de repli** : llama-3.3-70b-versatile → llama-3.1-8b-instant → gemma2-9b-it selon l'attempt.
- **10 styles de prompt** : tirés aléatoirement à chaque message (rage, mépris, roast, ultra-court, verlan, nihiliste, rhétorique, répétition moqueuse, comparaison, lassitude).
- **Prompts contextuels** : chaque prompt inclut le message reçu et demande au modèle d'y réagir spécifiquement.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Ne jamais appeler `pnpm dev` à la racine — utiliser le workflow Replit.
- Après un changement de code → rebuild obligatoire (`pnpm --filter @workspace/api-server run build`).
- Le Dockerfile utilise `corepack` pour pnpm — la version est épinglée à `10.26.1`.
