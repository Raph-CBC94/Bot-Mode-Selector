import {
  Client,
  Events,
  GatewayIntentBits,
  Message,
  TextChannel,
} from "discord.js";
import OpenAI from "openai";
import { logger } from "../lib/logger";

// ──────────────────────────────────────────────
// LISTE D'INSULTES — 150+ entrées
// ──────────────────────────────────────────────

const INSULT_LIST = [
  // Abréviations classiques
  "NTM", "FDP", "FTG", "VTF", "VTFF", "TG", "PDTG",
  "NTM FDP", "FTG FDP", "VTF FDP", "NTM FTG", "VTFF FDP",

  // Nique / viole — formules directes
  "Nique ta mère", "Nique ta race", "Nique ta grand-mère",
  "Nique ta sœur", "Nique ton père", "Nique ta famille",
  "Nique ta gueule", "Nique ta vie", "Nique tout ce que t'aimes",
  "Je viole ton père", "Je viole ta mère", "Je viole ta race",
  "On a niqué ta mère", "Ta mère on l'a niquée", "Ta sœur on l'a niquée",
  "Nique ta mère FDP", "Nique ta race NTM", "Nique ta mère et toute ta lignée",

  // Fils de / mère
  "Fils de pute", "Sale fils de pute", "Fils de pute de compétition",
  "Fils de chien", "Fils de merde", "Fils de porc",
  "Sale produit de ta mère", "Ta mère la pute", "Ta mère la grande",
  "Bâtard de sa mère", "Fils de ta race",
  "Ta mère la chienne", "Ta mère vend des cacahuètes",
  "Ta mère elle fait quoi ce soir",

  // Enculé / variantes
  "Enculé", "Sale enculé", "Gros enculé", "Enculé de merde",
  "Enculé de première", "Enculé de compétition", "Enculé puissance mille",
  "Grand enculé", "Double enculé", "Enculé intersidéral",

  // Bâtard
  "Sale bâtard", "Bâtard de merde", "Bâtard de première",
  "Gros bâtard", "Putain de bâtard", "Bâtard de compétition",

  // Merde / variantes
  "Sale merde", "Grosse merde", "Sous-merde", "Sac à merde",
  "Tas de merde", "Grosse merde humaine", "Putain de merde ambulante",
  "Crotte de merde", "Tas de merde cosmique", "Merde intégrale",
  "Double merde", "Merde de première", "Merde en boîte",

  // Ordure / pourriture
  "Sale ordure", "Grosse ordure", "Putain d'ordure", "Ordure de première",
  "Sale pourriture", "Pourriture humaine", "Pourriture de fond de chiotte",
  "Ordure intersidérale", "Grosse ordure de compétition",

  // Raclure / chiotte
  "Sale raclure", "Putain de raclure", "Raclure de fond de chiotte",
  "Grosse raclure de chiotte", "Raclure de l'humanité",
  "Fond de chiotte", "Déchet de chiotte", "Résidu de chiotte",

  // Enflure / enfoiré
  "Sale enflure", "Putain d'enflure", "Enflure de compétition",
  "Putain d'enfoiré", "Sale enfoiré", "Enfoiré de première",
  "Gros enfoiré", "Enfoiré de merde", "Double enfoiré",

  // Connard / connasse
  "Connard", "Putain de connard", "Connard de compétition",
  "Connard intersidéral", "Connard puissance mille", "Gros connard",
  "Sale connard", "Connard de première", "Connard en chef",

  // Tête / face / gueule
  "Tête de bite", "Tête de nœud", "Tête de gland", "Face de cul",
  "Gueule de merde", "Gueule de raclure", "Tête de con",
  "Face de déchet", "Gueule d'enfoiré", "Tête de sac",

  // Déchet / rebut / vermine
  "Déchet humain", "Déchet de l'humanité", "Putain de déchet",
  "Rebut de l'humanité", "Résidu d'humanité", "Déchet de société",
  "Sale vermine", "Putain de vermine", "Vermine de première",
  "Parasite de merde", "Sale parasite", "Parasite humain",
  "Crotte ambulante", "Rebut cosmique", "Sous-produit de l'humanité",

  // Con / idiot / nul
  "Gros con", "Sale con", "Con de première", "Con puissance mille",
  "Espèce de con", "Grand con", "Connasse de merde",
  "Gros idiot de merde", "Crétin de compétition", "Abruti de service",
  "Demeuré de première", "Attardé de merde", "Arriéré complet",
  "Gros bouffon", "Bouffon de première", "Bouffon intersidéral",
  "Clown de merde", "Guignol de service",

  // Zéro / inutile
  "Zéro absolu", "Inutile de naissance", "Décervelle complet",
  "Cerveau de fourmi", "QI de limace", "Cerveau de plancton",
  "Inutile cosmique", "Nul de chez nul", "Le plus nul de l'univers",
  "Zéro puissance infinie",

  // Composés créatifs
  "Ferme ta putain de gueule",
  "Ta gueule sale FDP",
  "NTM sale enculé de merde",
  "Gros fils de pute de compétition",
  "Raclure de chiotte intersidérale",
  "Sous-merde ambulante",
  "Déchet humain de première",
  "Ordure cosmique de merde",
  "Grand bâtard de sa race",
  "Double enculé de compétition",
];

const INSULT_KEYWORDS = [
  "ntm", "fdp", "ftg", "vtf", "vtff", "tg", "pdtg",
  "nique", "viole", "niqué", "niquée",
  "enculé", "bâtard", "merde", "ordure", "pourriture", "raclure",
  "chiotte", "enflure", "enfoiré", "vermine", "parasite", "connard",
  "pute", "bite", "nœud", "gland", "cul", "déchet", "rebut",
  "crotte", "inutile", "bouffon", "clown", "guignol", "crétin",
  "abruti", "demeuré", "arriéré", "con ", " con", "connasse",
  "ta gueule", "ferme ta", "fils de", "ta mère", "sa mère",
  "résidu", "sous-merde", "sous-produit", "grand con", "gros con",
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

/** Tire 2 insultes différentes aléatoirement */
function pickTwo(): [string, string] {
  const a = pick(INSULT_LIST);
  let b = pick(INSULT_LIST);
  while (b === a) b = pick(INSULT_LIST);
  return [a, b];
}

function containsInsult(text: string): boolean {
  const lower = text.toLowerCase();
  return INSULT_KEYWORDS.some((kw) => lower.includes(kw));
}

// ──────────────────────────────────────────────
// SUFFIXE ALÉATOIRE — 50% des messages
// ──────────────────────────────────────────────

const SUFFIXES = ["btw", "🫩✌🏻", "btw🫩✌🏻"] as const;
const SUFFIX_STRIP_RE = /[\s,]+(?:btw\s*🫩✌🏻|btw|🫩✌🏻)\s*$/i;

function withSuffix(text: string): string {
  // Retire d'abord tout suffixe déjà présent (mis par le LLM ou le fallback)
  const clean = text.replace(SUFFIX_STRIP_RE, "").trimEnd();
  // 50% de chance d'ajouter un suffixe
  if (Math.random() < 0.5) {
    const suffix = SUFFIXES[Math.floor(Math.random() * SUFFIXES.length)]!;
    return `${clean} ${suffix}`;
  }
  return clean;
}

// ──────────────────────────────────────────────
// PSEUDO — TRONCATURE
// ──────────────────────────────────────────────

function shortenUsername(username: string, maxLen = 12): string {
  if (username.length <= maxLen) return username;
  return username.slice(0, maxLen - 2) + "..";
}

// ──────────────────────────────────────────────
// FALLBACKS — 30 TEMPLATES VARIÉS
// ──────────────────────────────────────────────

const FALLBACK_TEMPLATES = [
  (u: string, a: string, b: string, msg: string) =>
    msg.length > 3 ? `"${msg.slice(0, 18)}" lmao ${a} ${u} ${b.toLowerCase()} tg` : `${a} ${u} ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `${a} ${u} t'es un gros ${b.toLowerCase()} ferme ta gueule`,
  (u: string, a: string, b: string) => `ntm ${u} ${a.toLowerCase()} ${b.toLowerCase()} tg`,
  (u: string, a: string, b: string) => `${a} ${u} sérieusement ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `vtff ${u} ${a.toLowerCase()} et ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `ferme ta gueule ${u} ${a.toLowerCase()} de ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `lmao ${u} ${a.toLowerCase()} va mourir ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `${u} t'es un ${a.toLowerCase()} doublé d'un ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `lmaooo ${u} gros ${a.toLowerCase()} ${b.toLowerCase()} rentre chez toi`,
  (u: string, a: string, b: string) => `${u} franchement ${a.toLowerCase()} ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `on s'en branle ${u} ${a.toLowerCase()} va dormir ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `tg ${u} ${a.toLowerCase()} et ${b.toLowerCase()} merci`,
  (u: string, a: string, b: string) => `${a} ${u} personne t'a rien demandé ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `mais ${a.toLowerCase()} ${u} t'es vraiment un ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `${u} c'est quoi ce délire ${a.toLowerCase()} ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `aaah ${u} ${a.toLowerCase()} tg déjà ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `${a} et ${b} ${u} va te coucher`,
  (u: string, a: string, b: string) => `wallah ${u} ${a.toLowerCase()} ${b.toLowerCase()} laisse tomber`,
  (u: string, a: string, b: string) => `${u} va falloir que tu te taises ${a.toLowerCase()} ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `sors de là ${u} ${a.toLowerCase()} ${b.toLowerCase()} btw 🫩✌🏻`,
  (u: string, a: string, b: string) => `nan mais ${u} ${a.toLowerCase()} t'es vraiment ${b.toLowerCase()} lmao`,
  (u: string, a: string, b: string) => `${a} ${u} tu m'épuises ${b.toLowerCase()} tg`,
  (u: string, a: string, b: string) => `oh ${u} ${a.toLowerCase()} ${b.toLowerCase()} va mourir stp`,
  (u: string, a: string, b: string) => `${u} j'en reviens pas ${a.toLowerCase()} ${b.toLowerCase()}`,
  (u: string, a: string, b: string) => `ta gueule ${u} ${a.toLowerCase()} ${b.toLowerCase()} fin de la discussion`,
];

function fallbackInsult(username: string, messageContent: string): string {
  const [a, b] = pickTwo();
  const template = pick(FALLBACK_TEMPLATES);
  return withSuffix(template(shortenUsername(username), a, b, messageContent.slice(0, 25)));
}

// ──────────────────────────────────────────────
// ROTATION ALÉATOIRE DES CLÉS API GROQ
// ──────────────────────────────────────────────

interface GroqClient {
  client: OpenAI;
  key: string;
  rateLimitedUntil: number;
}

function loadGroqClients(): GroqClient[] {
  const clients: GroqClient[] = [];
  const legacy = process.env["GROQ_API_KEY"];
  if (legacy) {
    clients.push({
      client: new OpenAI({ baseURL: "https://api.groq.com/openai/v1", apiKey: legacy }),
      key: legacy,
      rateLimitedUntil: 0,
    });
  }
  for (let i = 1; i <= 20; i++) {
    const key = process.env[`GROQ_API_KEY_${i}`];
    if (!key) break;
    clients.push({
      client: new OpenAI({ baseURL: "https://api.groq.com/openai/v1", apiKey: key }),
      key,
      rateLimitedUntil: 0,
    });
  }
  return clients;
}

function pickAvailableClient(clients: GroqClient[]): GroqClient | null {
  const now = Date.now();
  const available = clients.filter((c) => c.rateLimitedUntil <= now);
  if (available.length === 0) {
    return clients.reduce((a, b) => (a.rateLimitedUntil < b.rateLimitedUntil ? a : b));
  }
  return available[Math.floor(Math.random() * available.length)]!;
}

function markRateLimited(entry: GroqClient, retryAfterSec = 30): void {
  entry.rateLimitedUntil = Date.now() + retryAfterSec * 1000;
  logger.warn(
    { keyPrefix: entry.key.slice(0, 8) + "...", retryAfterSec },
    "Clé Groq rate-limitée, mise en cooldown",
  );
}

// ──────────────────────────────────────────────
// STYLES DE PROMPT — 12 VARIATIONS ULTRA-AGRESSIVES
// ──────────────────────────────────────────────

function buildPrompt(username: string, messageContent: string): string {
  const [ins1, ins2] = pickTwo();
  const shortName = shortenUsername(username);
  const excerpt = messageContent.slice(0, 120).trim();

  const pseudoInstruction = `VANNE SUR LE PSEUDO (obligatoire) : analyse le pseudo "${shortName}" et invente une moquerie UNIQUE et SPÉCIFIQUE basée sur ce pseudo précis — ses lettres, ses chiffres, sa sonorité, ce que le mot évoque, si c'est prétentieux/nul/edgy/banal/bizarre. PAS de formule générique type "ton pseudo c'est nul". Sois créatif et précis.`;

  const violence = `NIVEAU DE VIOLENCE : MAXIMAL. Aucune retenue. Chaque réponse doit être une attaque frontale, brutale, sans filtre. Cumule plusieurs insultes dans une même phrase. Le but est de dévaster en une réponse.`;

  // ⚠️ Règle critique JSON — ajoutée à chaque style
  const noQuotesRule = `\nRÈGLE JSON CRITIQUE : la valeur de "reply" ne doit JAMAIS contenir de guillemets doubles ( " ). Si tu veux citer quelque chose, utilise des guillemets simples ( ' ) ou des chevrons ( « » ). Exemple valide : {"reply":"lmao t'as dit ça ? ntm fdp"} — Exemple INVALIDE : {"reply":"il dit \\"bonjour\\""}. Toute réponse avec des guillemets doubles à l'intérieur sera rejetée.`;

  const styles: string[] = [
    // 0 — RAGE BRUTE DOUBLE INSULTE
    `Tu es un bot Discord d'une violence verbale extrême. Tu empiles les insultes sans pitié.
${violence}
INSULTES OBLIGATOIRES : utilise "${ins1}" ET "${ins2}" dans ta réponse.
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Réagis à ce message en démolissant son auteur. Empile les insultes, mets le pseudo, sois dévastateur.
EXEMPLES :
- "${ins1} ${shortName} gros ${ins2.toLowerCase()} ferme ta putain de gueule btw 🫩✌🏻"
- "ntm ${shortName} t'es un ${ins1.toLowerCase()} doublé d'un ${ins2.toLowerCase()} tg"
- "nan mais ${ins1} ${shortName} t'as vraiment dit ça ? ${ins2.toLowerCase()} sors de là"
RÈGLES : 8-15 mots, pseudo présent, 2 insultes minimum, JAMAIS de douceur.
JSON : {"reply":"..."}`,

    // 1 — MÉPRIS TOTAL CONTEXTUEL
    `Tu es un bot Discord qui écrase les gens avec un mépris absolu et des insultes lourdes.
${violence}
INSULTES OBLIGATOIRES : utilise "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Lis ce message, réagis à son contenu, montre ton dégoût total avec des insultes cumulées.
EXEMPLES :
- "${shortName} ${ins1.toLowerCase()} t'as vraiment cru que quelqu'un s'en foutait pas de ça ? ${ins2.toLowerCase()} btw 🫩✌🏻"
- "nan mais le ${ins1.toLowerCase()} ${ins2.toLowerCase()} ${shortName} qui parle LMAOOO"
- "${ins1} ${shortName} ${ins2.toLowerCase()} de niveau zéro absolu tg"
RÈGLES : 8-16 mots, réagit au message, 2 insultes min, condescendant et violent.
JSON : {"reply":"..."}`,

    // 2 — ROAST DÉVASTATEUR
    `Tu es un bot Discord spécialisé dans les roasts dévastateurs — humiliants, précis, ultra-violents.
${violence}
INSULTES OBLIGATOIRES : utilise "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Roaste ce message et son auteur avec précision. Utilise ce qu'il a dit contre lui.
EXEMPLES :
- "${ins1} ${shortName} t'as dit ça avec tes 2 neurones ? ${ins2.toLowerCase()} lmao"
- "lmaooo ${shortName} ${ins1.toLowerCase()} t'aurais dû te taire ${ins2.toLowerCase()} btw 🫩✌🏻"
- "${ins1} ${ins2} ${shortName} le plus pathétique du serveur confirme"
RÈGLES : roast contextuel précis, 2 insultes min, 7-16 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 3 — ULTRA COURT BRUTAL (4-6 mots, 2 insultes)
    `Tu es un bot Discord brutal. Réponds en 4 à 6 mots MAXIMUM, ultra direct, avec 2 insultes.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
MESSAGE REÇU : "${excerpt}"
EXEMPLES :
- "${ins1} ${shortName} ${ins2.toLowerCase()} tg"
- "ntm ${shortName} ${ins1.toLowerCase()} ${ins2.toLowerCase()}"
- "${ins1} ${ins2} ${shortName} bye"
- "tg ${ins1.toLowerCase()} ${ins2.toLowerCase()} ${shortName}"
RÈGLES : 4-6 mots MAX, 2 insultes, brutal et sec.
JSON : {"reply":"..."}`,

    // 4 — ARGOT / VERLAN VIOLENT
    `Tu es un bot Discord qui parle en argot parisien avec une violence verbale maximale.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Réagis en argot/verlan, cumule les insultes, démolis le message.
EXEMPLES :
- "wallah ${shortName} t'es un ${ins1.toLowerCase()} et un ${ins2.toLowerCase()} de la pire espèce frère"
- "${shortName} ${ins1.toLowerCase()} laisse tomber reuf t'es un ${ins2.toLowerCase()} btw 🫩✌🏻"
- "on va pas se mentir ${shortName} ${ins1.toLowerCase()} ${ins2.toLowerCase()} tg"
RÈGLES : argot naturel, 2 insultes min, 6-14 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 5 — NIHILISTE DÉVASTATEUR
    `Tu es un bot Discord nihiliste qui détruit les gens existentiellement avec une violence verbale totale.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
EXEMPLES :
- "${ins1} ${shortName} ta vie est une erreur, t'es un ${ins2.toLowerCase()} que l'univers a raté btw 🫩✌🏻"
- "l'humanité aurait été meilleure sans toi ${shortName} gros ${ins1.toLowerCase()} ${ins2.toLowerCase()}"
- "${shortName} ${ins1.toLowerCase()} ${ins2.toLowerCase()} ta contribution à ce monde c'est rien"
RÈGLES : nihiliste et dévastateur, 2 insultes min, 8-16 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 6 — QUESTION RHÉTORIQUE VIOLENTE
    `Tu es un bot Discord qui insulte violemment via des questions/exclamations dévastatrices.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
EXEMPLES :
- "mais ${ins1} ${shortName} ${ins2.toLowerCase()} t'as vraiment envoyé ça ?"
- "${shortName} ${ins1.toLowerCase()} tu te prends pour qui ${ins2.toLowerCase()} ?"
- "c'est ça que t'as trouvé à dire ${shortName} ? ${ins1.toLowerCase()} ${ins2.toLowerCase()} sérieusement"
RÈGLES : question ou exclamation, 2 insultes min, 7-16 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 7 — RÉPÉTITION MOQUEUSE VIOLENTE
    `Tu es un bot Discord qui cite et crucifie ce que dit la personne avec insultes multiples.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Cite un bout du message entre guillemets, puis démolis l'auteur.
EXEMPLES :
- '"${excerpt.slice(0, 15)}" lmaooo ${ins1} ${shortName} ${ins2.toLowerCase()} va dormir'
- "nan le ${ins1.toLowerCase()} ${ins2.toLowerCase()} ${shortName} qui dit ça LMAOOO"
- "${shortName} ${ins1.toLowerCase()} t'as dit ça ? ${ins2.toLowerCase()} allez bye"
RÈGLES : cite le message, 2 insultes min, moqueur et violent, 6-14 mots.
JSON : {"reply":"..."}`,

    // 8 — COMPARAISON DÉGRADANTE VIOLENTE
    `Tu es un bot Discord qui humilie via des comparaisons dégradantes créatives avec insultes multiples.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Fais une comparaison humiliante en rapport avec le message, empile les insultes.
EXEMPLES :
- "${ins1} ${shortName} même une limace aurait dit mieux ${ins2.toLowerCase()} btw 🫩✌🏻"
- "${shortName} ${ins1.toLowerCase()} t'as le QI d'un parpaing mouillé ${ins2.toLowerCase()} tg"
- "${ins1} ${ins2} ${shortName} même ta chaussette gauche vaut plus que toi"
RÈGLES : comparaison créative, 2 insultes min, 7-16 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 9 — LASSITUDE AGRESSIVE EXTRÊME
    `Tu es un bot Discord épuisé et enragé par l'existence même de cette personne.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
EXEMPLES :
- "aaah ${ins1} ${shortName} encore ce ${ins2.toLowerCase()} qui parle j'en peux plus tg btw 🫩✌🏻"
- "${shortName} ${ins1.toLowerCase()} ${ins2.toLowerCase()} tu me saoules au niveau atomique"
- "oh ${ins1} ${shortName} ${ins2.toLowerCase()} va te coucher pour de bon"
RÈGLES : épuisé + enragé, 2 insultes min, 7-16 mots, pseudo présent.
JSON : {"reply":"..."}`,

    // 10 — ACCUMULATION PURE (liste d'insultes en cascade)
    `Tu es un bot Discord qui répond en enchaînant les insultes sans respirer.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}" — et ajoutes-en d'autres de ton invention.
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Enchaîne 3 à 5 insultes différentes en une seule phrase explosive qui démarre ou se termine par le pseudo.
EXEMPLES :
- "${shortName} ${ins1.toLowerCase()} ${ins2.toLowerCase()} tête de con ferme ta putain de gueule btw 🫩✌🏻"
- "ntm ${ins1.toLowerCase()} ${ins2.toLowerCase()} ${shortName} fils de pute tg sérieux"
- "${ins1} ${ins2} ${shortName} gros connard raclure de chiotte va crever"
RÈGLES : cascade de 3-5 insultes, une seule phrase, pseudo présent, ultra-violent.
JSON : {"reply":"..."}`,

    // 11 — TACLE CONTEXTUEL PRÉCIS
    `Tu es un bot Discord qui fait des tacl es précis et dévastateurs sur ce que dit exactement la personne.
${violence}
INSULTES OBLIGATOIRES : "${ins1}" ET "${ins2}".
${pseudoInstruction}
MESSAGE REÇU : "${excerpt}"
Utilise PRÉCISÉMENT le contenu du message pour le retourner contre lui et l'insulter violemment.
EXEMPLES :
- "${shortName} ${ins1.toLowerCase()} t'as osé dire ça avec ta gueule ? ${ins2.toLowerCase()} btw 🫩✌🏻"
- "lmao ${ins1} ${shortName} même si t'avais raison, ${ins2.toLowerCase()} tg quand même"
- "${ins1} ${shortName} c'est toi qui dis ça ? ${ins2.toLowerCase()} retourne à l'école"
RÈGLES : tacle précis sur le contenu du message, 2 insultes min, 8-16 mots, pseudo présent.
JSON : {"reply":"..."}`,
  ];

  return styles[Math.floor(Math.random() * styles.length)]! + noQuotesRule;
}

// ──────────────────────────────────────────────
// PARSE JSON
// ──────────────────────────────────────────────

function parseReply(raw: string): string | null {
  const cleaned = raw.trim().replace(/^```json?\s*/i, "").replace(/```\s*$/i, "");
  try {
    const parsed = JSON.parse(cleaned) as unknown;
    if (typeof parsed === "object" && parsed !== null && "reply" in parsed) {
      const r = (parsed as Record<string, unknown>)["reply"];
      if (typeof r === "string" && r.trim().length > 0) return r.trim();
    }
  } catch {
    const match = /"reply"\s*:\s*"((?:[^"\\]|\\.)*)"/i.exec(cleaned);
    if (match?.[1]) return match[1].replace(/\\n/g, "\n").replace(/\\"/g, '"').trim();
  }
  return null;
}

// ──────────────────────────────────────────────
// MODÈLES GROQ (ordre de préférence)
// ──────────────────────────────────────────────

const MODELS = [
  "llama-3.3-70b-versatile",
  "llama-3.1-8b-instant",
  "gemma2-9b-it",
];

// ──────────────────────────────────────────────
// APPEL API AVEC RETRY SUR 429
// ──────────────────────────────────────────────

async function callGroqWithRetry(
  clients: GroqClient[],
  username: string,
  messageContent: string,
): Promise<string> {
  const maxAttempts = Math.min(clients.length * 2, 6);

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const entry = pickAvailableClient(clients);
    if (!entry) break;

    const model = MODELS[Math.min(attempt, MODELS.length - 1)]!;
    const prompt = buildPrompt(username, messageContent);

    try {
      const completion = await entry.client.chat.completions.create(
        {
          model,
          max_completion_tokens: 120,
          temperature: 1.2,
          messages: [
            { role: "system", content: prompt },
            {
              role: "user",
              content: `${username} dit : "${messageContent.slice(0, 200)}"`,
            },
          ],
          response_format: { type: "json_object" },
        },
        { signal: AbortSignal.timeout(12_000) },
      );

      const raw = completion.choices[0]?.message?.content?.trim() ?? "";
      const parsed = parseReply(raw);

      if (parsed && containsInsult(parsed)) {
        const reply = withSuffix(parsed);
        logger.debug({ model, attempt, reply }, "Réponse IA valide");
        return reply;
      }

      logger.warn({ raw, parsed, attempt }, "Réponse IA sans insulte → fallback local");
      return fallbackInsult(username, messageContent);
    } catch (err: unknown) {
      const status = (err as { status?: number }).status;
      const message = (err as { message?: string }).message ?? "";

      if (status === 429 || message.includes("rate limit") || message.includes("Rate limit")) {
        const retryMatch = /try again in (\d+\.?\d*)s/i.exec(message);
        const retrySec = retryMatch ? Math.ceil(parseFloat(retryMatch[1]!)) + 2 : 35;
        markRateLimited(entry, retrySec);
        logger.warn(
          { attempt, model, retrySec },
          `Rate limit hit, tentative ${attempt + 1}/${maxAttempts}`,
        );
        continue;
      }

      // 400 json_validate_failed → le LLM a mis des guillemets doubles → retry
      if (status === 400 && message.includes("json_validate_failed")) {
        logger.warn({ attempt, model }, `json_validate_failed, retry ${attempt + 1}/${maxAttempts}`);
        continue;
      }

      logger.error({ err, attempt }, "Erreur API non rate-limit");
      return fallbackInsult(username, messageContent);
    }
  }

  logger.warn("Toutes les clés épuisées → fallback");
  return fallbackInsult(username, messageContent);
}

// ──────────────────────────────────────────────
// FILE D'ATTENTE PAR SALON (anti-crash multi-messages)
// ──────────────────────────────────────────────

const channelQueues = new Map<string, Promise<void>>();

function enqueueForChannel(channelId: string, task: () => Promise<void>): void {
  const current = channelQueues.get(channelId) ?? Promise.resolve();
  const next = current
    .then(() => task())
    .catch((err) => {
      logger.error({ err, channelId }, "Erreur dans la file du salon");
    });
  channelQueues.set(channelId, next);

  next.finally(() => {
    if (channelQueues.get(channelId) === next) {
      channelQueues.delete(channelId);
    }
  });
}

// ──────────────────────────────────────────────
// DÉMARRAGE DU BOT
// ──────────────────────────────────────────────

export async function startBot(): Promise<void> {
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    logger.warn("DISCORD_BOT_TOKEN non défini — le bot Discord ne démarrera pas");
    return;
  }

  const allowedChannelId = process.env["ALLOWED_CHANNEL_ID"]?.trim() || null;
  if (allowedChannelId) {
    logger.info({ channelId: allowedChannelId }, "Mode salon unique activé");
  } else {
    logger.warn("ALLOWED_CHANNEL_ID non défini — le bot répond dans tous les salons");
  }

  const groqClients = loadGroqClients();
  if (groqClients.length === 0) {
    logger.error("Aucune GROQ_API_KEY trouvée — bot non démarré");
    return;
  }

  logger.info({ count: groqClients.length }, `${groqClients.length} clé(s) Groq chargée(s)`);

  const discordClient = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });

  discordClient.once(Events.ClientReady, (c) => {
    logger.info({ tag: c.user.tag }, "Bot Discord connecté ✅");
  });

  discordClient.on(Events.MessageCreate, (message: Message) => {
    if (message.author.bot) return;
    if (allowedChannelId && message.channelId !== allowedChannelId) return;

    const username = message.author.username;
    const channelId = message.channelId;
    const messageContent = message.content;

    enqueueForChannel(channelId, async () => {
      if (message.channel instanceof TextChannel) {
        await message.channel.sendTyping().catch(() => {});
      }

      const finalReply = await callGroqWithRetry(groqClients, username, messageContent);

      try {
        await message.reply(finalReply);
      } catch {
        try {
          if (message.channel instanceof TextChannel) {
            await message.channel.send(`${shortenUsername(username)} ${finalReply}`);
          }
        } catch (err2) {
          logger.error({ err2 }, "Impossible d'envoyer la réponse");
        }
      }
    });
  });

  discordClient.on(Events.Error, (err) => logger.error({ err }, "Erreur client Discord"));
  discordClient.on(Events.ShardDisconnect, (event, shardId) => {
    logger.warn({ shardId, code: event.code }, "Bot Discord déconnecté");
  });

  await discordClient.login(token);
}
